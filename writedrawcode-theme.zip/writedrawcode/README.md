# writeDRAWcode — micro.blog theme

A minimal, text-first theme. Uses the device's own font. Light and dark mode follow the system setting.

## Structure

```
theme.json
layouts/
  index.html            home (paginated post list)
  _default/list.html    archives, categories
  _default/single.html  one post or page
  partials/
    head.html  header.html  footer.html
    post-item.html      list entry (titled post or untitled note)
    pagination.html
static/
  theme.css             all styling, driven by CSS custom properties
```

## Design tokens

Everything lives in `:root` at the top of `static/theme.css`. Change `--link` or `--bg` there and the whole theme follows. Dark values are in the `prefers-color-scheme: dark` block right below.

## Micro.blog notes

- Untitled posts render as notes: body plus a date link, no heading.
- Posts use microformats classes (`h-entry`, `p-name`, `e-content`, `dt-published`, `u-url`, `p-category`).
- The tagline comes from the blog's description. Navigation comes from the main menu; if none is set, it falls back to Home and Archive.
